```markdown
# Design System Specification: The Sonic Gallery

## 1. Overview & Creative North Star
**Creative North Star: "The Immersive Gallery"**
This design system moves away from the "utility-first" clutter of traditional music players, treating every album, playlist, and track as a curated piece of art. We reject the rigid, boxy constraints of standard Android apps in favor of **Organic Editorialism**. By leveraging Material 3’s expressive capabilities, we create a sense of "Atmospheric Immersion" where the interface breathes and adapts to the music being played.

The system breaks the "template" look through:
*   **Intentional Asymmetry:** Off-center typography and staggered grids to create a rhythmic visual flow.
*   **Variable Weight Expression:** Using the weight of the font to represent the "weight" of the sound.
*   **Extreme Radials:** Embracing the "Extra-Large" shape category to make the UI feel soft, tactile, and premium.

---

## 2. Colors & Tonal Depth
The color strategy is rooted in a deep, nocturnal palette (`background: #120b1a`) that allows the vibrant accents of `primary (#dacdff)` and `tertiary (#eeffdd)` to glow like neon signage in a dark room.

### The "No-Line" Rule
**Explicit Instruction:** You are prohibited from using 1px solid borders to define sections. Layout boundaries must be established solely through background color shifts. 
*   Example: A list of tracks should sit on `surface_container_low`, while the active track card uses `surface_container_high`. 

### Surface Hierarchy & Nesting
Treat the UI as a physical stack of semi-transparent layers.
*   **Base:** `surface` (#120b1a) - The canvas.
*   **Sectioning:** Use `surface_container_low` (#171021) for large grouped areas.
*   **Emphasis:** Use `surface_container_highest` (#2c203c) for interactive elements like the mini-player or pop-out menus.

### The "Glass & Gradient" Rule
To elevate the player beyond a standard flat UI, the "Now Playing" bar and floating action buttons should utilize **Glassmorphism**.
*   **Implementation:** Use a semi-transparent `surface_container_highest` (approx. 70% opacity) with a `32px` backdrop-blur. 
*   **Signature Textures:** For primary CTAs (e.g., "Play" button), use a linear gradient transitioning from `primary` (#dacdff) to `primary_container` (#cdbdff) at a 135-degree angle. This adds a subtle "soul" to the component that flat hex codes cannot achieve.

---

## 3. Typography: The Editorial Voice
We use a high-contrast pairing to establish an editorial feel: **Epilogue** for expression and **Manrope** for utility.

*   **Display & Headline (Epilogue):** This is our "Brutalist" anchor. Use `display-lg` (3.5rem) for artist names in the "Now Playing" screen. Leverage variable weights—thin weights for subtle metadata and extra-bold for track titles.
*   **Body & Labels (Manrope):** A clean, technical sans-serif. Use `body-md` (0.875rem) for track durations and album details.
*   **The Hierarchy Strategy:** Use `title-lg` (Manrope, 1.375rem) for playlist headers to maintain a sophisticated, clean structure that doesn't compete with the art-focused headlines.

---

## 4. Elevation & Depth
In this design system, "Elevation" is a measure of light and tone, not just shadow.

### The Layering Principle
Depth is achieved by "stacking" tonal tiers. Place a `surface_container_lowest` (#000000) element inside a `surface_container_low` (#171021) environment to create a "sunken" well effect for search bars. 

### Ambient Shadows
Shadows are a last resort. When a floating state is required (e.g., a dragged playlist item):
*   **Blur:** `32px` to `48px` (Extra-diffused).
*   **Color:** Use `on_surface` (#f0dfff) at **4% to 8% opacity**. This creates a soft, purple-tinted glow that mimics natural ambient light within the dark theme, rather than a muddy grey drop shadow.

### The "Ghost Border" Fallback
If accessibility testing requires a container boundary, use a **Ghost Border**: `outline_variant` (#504260) at **15% opacity**. It should be felt, not seen.

---

## 5. Components

### The "Master Shape" (Cards & Containers)
Apply the **Extra-Large (xl)** shape category (`3rem` or `48px`) to all primary containers.
*   **Album Art Cards:** Use `xl` (3rem) rounding. 
*   **The "No-Divider" Rule:** Never use lines to separate list items. Use `spacing.6` (2rem) of vertical white space to let the content breathe.

### Buttons & Controls
*   **Primary Action (Play/Pause):** Use a `full` (9999px) rounded circle. Background: `primary` (#dacdff). Size: At least `80dp` to command the screen.
*   **Secondary Actions:** Use `xl` (3rem) rounded rectangles with `surface_container_high` (#251b33).
*   **State Layers:** On press, use the `primary` state layer at 12% opacity to provide immediate, tactile feedback.

### The Dynamic Mini-Player
This should feel like a floating "pill."
*   **Shape:** `full` (9999px).
*   **Surface:** Glassmorphic `surface_container_highest` with backdrop-blur.
*   **Padding:** Use `spacing.3` (1rem) internal padding and `spacing.4` (1.4rem) external margins to keep it detached from the screen edges.

### Input Fields
*   **Search Bar:** Use `surface_container_lowest` (#000000). 
*   **Shape:** `lg` (2rem). 
*   **Labeling:** `label-md` (Manrope, 0.75rem) in `on_surface_variant` (#b5a4c8).

---

## 6. Do's and Don'ts

### Do:
*   **Do** lean into white space. If a screen feels "empty," it’s likely working.
*   **Do** use `spacing.20` (7rem) or `spacing.24` (8.5rem) for top-of-page margins to create a high-end magazine feel.
*   **Do** use motion for transitions. Elements should "morph" from the `xl` card shape into the full-screen player using Material 3 container transform patterns.

### Don't:
*   **Don't** use 100% opaque white for text. Use `on_surface` (#f0dfff) for primary text and `on_surface_variant` (#b5a4c8) for secondary text to maintain the "purple-tinted" atmosphere.
*   **Don't** use sharp corners. The minimum corner radius allowed for any interactive element is `md` (1.5rem).
*   **Don't** use traditional "Material Blue." Stick strictly to the `primary` (#dacdff) and `tertiary` (#eeffdd) tonal palettes.